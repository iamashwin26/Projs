Madam,
I had to leave the lab early hance the lab performance that i had uploaded on the same day didnt contain the data for RC circut.
However this friday morning (2nd NOV) I did the experiment and the data is contained in the final Lab report.
Hence I request you to kindly re-evaluate my labperformace marks based on the data uploaded.
Thanking You
Yours Sincerely
Ashwin